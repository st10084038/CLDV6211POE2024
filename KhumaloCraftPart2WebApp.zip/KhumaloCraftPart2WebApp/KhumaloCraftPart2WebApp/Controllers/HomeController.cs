using KhumaloCraftPart2WebApp.Data;
using KhumaloCraftPart2WebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Linq;

namespace KhumaloCraftPart2WebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var products = _context.Products.ToList();
            return View(products);
        }
        public IActionResult About()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult MyWork()
        {
            var products = _context.Products.ToList();
            return View(products);
        }
        public class ProductController : Controller
        {
            private readonly ApplicationDbContext _context;

            public ProductController(ApplicationDbContext context)
            {
                _context = context;
            }
            public IActionResult Index()
            {
                var products = _context.Products.ToList();
                return View(products);
            }
            public IActionResult Create()
            {
                return View();
            }

            [HttpPost]
            public IActionResult Create(Products product)
            {
                if (ModelState.IsValid)
                {
                    _context.Products.Add(product);
                    _context.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                return View(product);
            }
            public IActionResult Order(int id)
            {
                var product = _context.Products.FirstOrDefault(p => p.ProductID == id);
                if (product == null || !product.IsAvailable)
                {
                    return NotFound();
                }
                return View(product);
            }

            [HttpPost]
            public IActionResult Order(int productId, int userId, int quantity)
            {
                var product = _context.Products.FirstOrDefault(p => p.ProductID == productId);
                if (product == null || !product.IsAvailable)
                {
                    return NotFound();
                }

                var transaction = new Transactions
                {
                    UserID = userId,
                    ProductID = productId,
                    Quantity = quantity,
                    TotalPrice = product.Price * quantity,
                    TransactionDate = DateTime.Now
                };

                _context.Transactions.Add(transaction);
                _context.SaveChanges();
                return RedirectToAction("MyOrders", "User", new { id = userId });
            }
            public class UserController : Controller
            {
                private readonly ApplicationDbContext _context;

                public UserController(ApplicationDbContext context)
                {
                    _context = context;
                }
                public IActionResult MyOrders(int id)
                {
                    var orders = _context.Transactions
                                         .Where(t => t.UserID == id)
                                         .Select(t => new
                                         {
                                             t.TransactionID,
                                             t.Products.ProductName,
                                             t.Quantity,
                                             t.TotalPrice,
                                             t.TransactionDate
                                         }).ToList();

                    return View(orders);
                }
                public IActionResult Orders()
                {
                    var orders = _context.Transactions
                                         .Select(t => new
                                         {
                                             t.TransactionID,
                                             t.UserID,
                                             t.Products.ProductName,
                                             t.Quantity,
                                             t.TotalPrice,
                                             t.TransactionDate
                                         }).ToList();

                    return View(orders);
                }
                



                public IActionResult Privacy()
                {
                    return View();
                }

                [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
                public IActionResult Error()
                {
                    return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
                }
            }
        }
    }
}

