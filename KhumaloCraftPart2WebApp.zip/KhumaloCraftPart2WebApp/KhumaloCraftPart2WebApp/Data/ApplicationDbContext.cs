﻿using Microsoft.EntityFrameworkCore;
using KhumaloCraftPart2WebApp.Models;

namespace KhumaloCraftPart2WebApp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
        public DbSet<Products> Products { get; set; }
        public DbSet<Transactions> Transactions { get; set; }
    }
}
