﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KhumaloCraftPart2WebApp.Models
{
    public class Transactions
    {
        [Key]
        public int TransactionID { get; set; }
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice { get; set; }
        public DateTime TransactionDate { get; set; }

        [ForeignKey("UserID")]
        public Users Users { get; set; }

        [ForeignKey("ProductID")]
        public Products Products { get; set; }
    }
}
